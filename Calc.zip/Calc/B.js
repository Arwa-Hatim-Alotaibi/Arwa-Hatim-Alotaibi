// $("button").click(function() {
//     alert("Button clicked");
// });
// var a = document.querySelector("#c")
// function cat() {
//     a.src = "g1.gif";
// }
// function dog() {
//     a.src = "giphy.gif";
// }

var b = " ";
var c = " ";
var d = "";
function clr() {
    b = " ";
document.getElementById("display").innerText = " ";
}
function press(a) {
    b+=a
    display.innerHTML = b;
}
function setOP(params) {
    c = params;
    d = b;
    b = "";
    display.innerHTML = c;
}
function calculate(params) {
    var e = parseInt(b);
    var f = parseInt(d);
    if (c == "+") {
        display.innerHTML = e+f;
    } else if (c == "-") {
        display.innerHTML = f-e;
    } else if (c == "/") {
        display.innerHTML = f/e;
    } else if (c == "*") {
        display.innerHTML = e*f;
    } 
}